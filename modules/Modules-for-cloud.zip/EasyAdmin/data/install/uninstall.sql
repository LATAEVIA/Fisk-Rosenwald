SET foreign_key_checks = 0;
DROP TABLE IF EXISTS content_lock;
